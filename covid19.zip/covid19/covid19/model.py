from django.db import models

"""
here it is where I design my database model and used those values to add the data 
based on my csv file store in phpadmin
"""


class FormdataForm(models.Model):
    prnameFR = models.CharField(max_length=100)
    date = models.CharField(max_length=100)

    numprob = models.CharField(max_length=100)
    numdeaths = models.CharField(max_length=100)
    numtotal = models.CharField(max_length=100)
