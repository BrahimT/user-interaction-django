from django import forms
from .model import FormdataForm
"""
I created a form model  for user interactions in case he/she
wants to add data to the database 
this form it is actually based on my model method attributes 
"""

class formdata(forms.ModelForm):
    class Meta:
        model = FormdataForm
        fields = [ "prnameFR","date","numprob","numdeaths","numtotal"]
        labels = { "prnameFpip install -U DjangoR": "prnameFR","date": "date","numprob": "numprob","numdeaths": "numdeaths","numtotal": "numtotal" }