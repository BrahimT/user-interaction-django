import unittest
from django.test import TestCase
from django.urls import resolve

from covid19.views import showdatadetails, myformData
"""
testing if there is any addition information that the user input by checking the views function of the form
"""
print('Brahim Boubakar Toure')
class MyTestCase(TestCase):
    def test_case_form_that_add_ata(self):
        found = resolve('form')
        self.assertEqual(found.func, myformData)


if __name__ == '__main__':
    unittest.main()
