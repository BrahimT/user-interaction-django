from django.shortcuts import render
from django.db import connection
from covid19.formdata import formdata

"""
in this view method,  I am using a phdadmin database by impoting the csv  file to my table ,
I retrieve the data through  a call stored procedure  and aster fetching them all , I 
simply render the html file
"""

def showdatadetails(request):
    cursor = connection.cursor()
    cursor.execute("call getdatafromcovidfile()")
    results = cursor.fetchall()
    return render(request, 'index.html', {'data': results})


"""
in this view method , I am saving the post , 
chequing the form validation  and render the file html to show 
the form html render 
"""


def myformData(request):
    if request.method == "POST":
        form = formdata(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = formdata()
    return render(request, 'addform.html', {'form': form})


"""
making request and render html file . 
"""


def update(request):
    return render(request, 'updateform.html')


"""
making request and render html file . 
"""


def delete(request):
    return render(request, 'deleteform.html')
